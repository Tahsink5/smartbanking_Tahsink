# bank_module.py

class Account:
    def __init__(self, acc_num, holder_name, pin):
        self.account_number = acc_num
        self.holder_name = holder_name
        self.pin = pin
        self.balance = 0
        self.transaction_history = []

    def deposit(self, amount):
        if amount > 0:
            self.balance += amount
            self.transaction_history.append(f"Deposit +{amount}")
            print(f"Deposited {amount}")
        else:
            print("Invalid deposit amount.")

    def withdraw(self, amount):
        if 0 < amount <= self.balance:
            self.balance -= amount
            self.transaction_history.append(f"Withdraw -{amount}")
            print(f"Withdrawn {amount}")
        else:
            print("Insufficient balance or invalid amount.")

    def show_balance(self):
        print(f"Current Balance: {self.balance}")

    def view_transactions(self):
        print("Transaction History:")
        for money in self.transaction_history[-10:]:
            print(money)


class Bank:
    def __init__(self):
        self.accounts = {}

    def create_account(self, acc_num, holder_name, pin):
        if acc_num not in self.accounts:
            self.accounts[acc_num] = Account(acc_num, holder_name, pin)
            print(" Account created successfully.")
        else:
            print(" Account number already exists.")

    def authenticate(self, acc_num, pin):
        account = self.accounts.get(acc_num)
        if account and account.pin == pin:
            print(" Login successful.")
            return account
        else:
            print("Authentication failed.")
            return None

            
    def transfer(self, sender_acc, receiver_acc, amount):
        if sender_acc.balance >= amount:
            sender_acc.balance -= amount
            receiver_acc.balance += amount
            sender_acc.transaction_history.append(f"Transfer Sent -{amount}")
            receiver_acc.transaction_history.append(f"Transfer Received +{amount}")
            print(f"Transferred {amount} from {sender_acc.holder_name} to {receiver_acc.holder_name}")
        else:
            print(" Insufficient balance for transfer.")
